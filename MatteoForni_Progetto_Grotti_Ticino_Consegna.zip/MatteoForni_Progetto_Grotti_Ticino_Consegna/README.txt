Per far funzionare l'applicativo:
- Modificare il percorso in codice/application/config/config.php della costante chiamata URL inserendo la root del progetto
- Modificare il percorso nel file in codice/.htaccess alla riga RewriteBase inserendo il percorso dalla root del webserver fino alla base del progetto (.../codice/)
- Caricare il database
- Se non funziona verificare che il modulo di rewrite nel webserver sia attivato e che l'override delle cartelle sia consentito.
PER ULTIMO PUNTO CAMBIARE:
 
<Directory /path/webserver/root/>
	AllowOverride None
	Require all denied
</Directory>

CON: 

<Directory /path/webserver/root/>
	AllowOverride All
	Require all granted
</Directory>
