drop database grotti;

/*CREAZIONE DEL DATABASE*/
create database grotti;
ALTER DATABASE grotti CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

use grotti;


create table ruolo(
	nome varchar(50) primary key
);

create table utente(
	email varchar(50) primary key,
    username varchar(50) not null,
    nome varchar(50) not null,
    cognome varchar(50) not null,
    password varchar(64) not null,
    reset_token varchar(30) unique,
    first_login tinyint(1),
    nome_ruolo varchar(50) not null,
    foreign key(nome_ruolo) references ruolo(nome)
);

create table fascia_prezzo(
	nome varchar(50) primary key
);

create table grotto(
	id int primary key auto_increment,
    nome varchar(50) not null,
    lon double not null,
    lat double not null,
    no_civico varchar(10) not null,
    via varchar(50) not null,
    paese varchar(50) not null,
    cap int not null,
    telefono varchar(20) not null,
    fascia_prezzo varchar(50) not null,
    valutazione double,
    verificato tinyint(1) not null,
    foreign key(fascia_prezzo) references fascia_prezzo(nome)
);

create table foto(
	id int primary key auto_increment,
    path varchar(255) unique not null,
    grotto int,
    foreign key(grotto) references grotto(id) on delete cascade
);

create table voto(
	id int primary key auto_increment,
	email_utente varchar(50),
    id_grotto int,
    voto float not null,
    foreign key(email_utente) references utente(email) on delete set null,
    foreign key(id_grotto) references grotto(id) on delete cascade
);

/*INSERIMENTO DEI DATI INIZIALI NEL DATABASE*/
insert into fascia_prezzo(nome) values ("Caro"),("Nella norma"),("Buon Prezzo");
insert into ruolo(nome) values ("admin"),("utente");

/*CREAZIONE DELL'UTENTE USATO DAL SITO*/
create user 'grotti_user'@'127.0.0.1' identified by 'GrottiUser&2019';
grant insert, update, select, delete on grotti.* to 'grotti_user'@'127.0.0.1';
flush privileges;
show grants for 'grotti_user'@'127.0.0.1';

/*CREAZIONE TRIGGER AFTER INSERT SULLA TABELLA VOTO*/
delimiter $$$
create trigger avg_after_review after insert on voto for each row
begin
	set @avg_review = (select avg(voto) from voto where id_grotto=NEW.id_grotto);
    set @avg_round = round(@avg_review*2)/2;
	update grotto set valutazione = @avg_round where id=NEW.id_grotto;
end;
$$$
delimiter ;