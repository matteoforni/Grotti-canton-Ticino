<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="my-5 text-center">
                <h1 class="h1">C'è stato un errore!</h1>
                <p class="mt-5">Prova a riconnetterti alla pagina precedente, se l'errore si ripete aspetta un'attimo.</p>
                <p>Messaggio e codice d'errore: <?php echo $_SESSION['warning']; ?></p>
            </div>
        </div>
    </div>
</div>